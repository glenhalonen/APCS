/**
 * @purpose: Calculate yearly CO2 emissions from electricity (8.10)
 *
 * @author:
 * @version:
 */
import java.util.ArrayList;
public class CO2FromElectricity

{
   CO2FromElectricity()
   {
   	//default constructor to be used
   }

   public double calcAverageBill(ArrayList<Double> monthlyBill)
   {
       // **** insert code for method here ****//
   }

   public double calcAveragePrice (ArrayList<Double> monthlyPrice)
   {
        // **** insert code for method here ****//
   }

   public double calcElectricityCO2 (double avgBill, double avgPrice)
   {
        // **** insert code for method here ****//
   }
}

